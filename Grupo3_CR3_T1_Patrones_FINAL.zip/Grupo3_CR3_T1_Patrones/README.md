# CR-3 T-1 Expo Patrones — Grupo 3 (entrega final)

Patrones de Diseño de Software, 2026-2 G02, Universidad Sergio Arboleda.
Integrantes: Santiago José Rodríguez Gutiérrez, Camilo Andrés Díaz García, Nicolás Steven
Pérez Chuscano.

## Contenido

- `Presentacion_Patrones_Grupo3_FINAL.pptx`: presentación (análisis, diseño, código
  explicado línea por línea y pruebas por patrón, con capturas reales de ejecución y de
  código).
- `GUION_DEMO.md`: guion de la demostración en vivo (3-4 min por patrón).
- `PREGUNTAS_PROFESOR.md`: 10 preguntas y respuesta por patrón, más hoja de repaso.
- `decorator/`, `facade/`, `flyweight/`, `proxy/`: un proyecto Java por patrón, cada uno
  con:
  - `src/`: código fuente propio (compila con `javac -encoding UTF-8 -d out src/*.java`
    y se ejecuta con `java "-Dstdout.encoding=UTF-8" -cp out Main` — agregar `--pausas`
    para la demo en vivo).
  - `diagramas/`: diagrama de clases y de secuencia (PlantUML + PNG).
  - `explicacion.md`: explicación línea por línea del código.

## Reparto para la demo en vivo

Camilo: Decorator y Facade · Santiago: Flyweight · Nicolás: Proxy.
